#1e5e53 - logo color
#299b85 - sub color

#3cd3ad - logo //for black